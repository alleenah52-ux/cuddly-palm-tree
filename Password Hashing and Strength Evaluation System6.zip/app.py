from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
import bcrypt
import hashlib
import secrets
import time
import json
import re
import math
from datetime import datetime
import logging
import argon2
# import scrypt
import pyscrypt as scrypt

import passlib.hash

# إعداد التسجيل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'auto-save-system-secret-key'
CORS(app)

# إعدادات قاعدة البيانات
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'password_security_system'
}

def get_db_connection():
    """إنشاء اتصال بقاعدة البيانات"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except mysql.connector.Error as e:
        logger.error(f"Database connection error: {e}")
        return None

class AutoSaveDatabaseManager:
    def __init__(self):
        self.common_passwords = self.load_common_passwords()
    
    def load_common_passwords(self):
        """تحميل كلمات المرور الشائعة"""
        try:
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                cursor.execute("SELECT password FROM common_passwords")
                common_passwords = [row[0] for row in cursor.fetchall()]
                cursor.close()
                conn.close()
                return common_passwords
        except Exception as e:
            logger.error(f"Error loading common passwords: {e}")
        return ['123456', 'password', '12345678']
    
    def auto_save_password(self, username, plain_password, password_hash):
        """حفظ تلقائي لأي يوزر وباسوورد"""
        try:
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                
                # استخدام الإجراء المخزن للحفظ التلقائي
                cursor.callproc('AutoSavePassword', [username, plain_password, password_hash])
                
                for result in cursor.stored_results():
                    save_result = result.fetchone()
                    user_id = save_result[0]
                    password_id = save_result[1]
                
                conn.commit()
                cursor.close()
                conn.close()
                
                logger.info(f"Auto-saved: User '{username}' with password length {len(plain_password)}")
                return user_id, password_id, None
                
        except mysql.connector.Error as e:
            logger.error(f"Auto-save error: {e}")
            return None, None, str(e)
        return None, None, "Unknown error"
    
    def save_password_hashes(self, password_id, hashes_data):
        try:
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                hash_ids = []
                
                for hash_data in hashes_data:
                    # الحصول على algorithm_id
                    cursor.execute(
                        "SELECT algorithm_id FROM hashing_algorithms WHERE algorithm_name = %s",
                        (hash_data['algorithm'],)
                    )
                    algorithm_result = cursor.fetchone()
                    
                    if algorithm_result:
                        algorithm_id = algorithm_result[0]
                        
                        cursor.execute(
                            """INSERT INTO password_hashes 
                            (password_id, algorithm_id, password_hash, salt, parameters, hashing_time_ms) 
                            VALUES (%s, %s, %s, %s, %s, %s)""",
                            (
                                password_id,
                                algorithm_id,
                                hash_data['hash'],
                                hash_data.get('salt', ''),
                                json.dumps(hash_data.get('parameters', {})),
                                hash_data['time']
                            )
                        )
                        hash_id = cursor.lastrowid
                        hash_ids.append(hash_id)
                        
                        # حفظ محاولة كسر حقيقية (بشكل منفصل مع معالجة الأخطاء)
                        try:
                            self.save_real_cracking_attempt(conn, hash_id, hash_data['algorithm'], hash_data['hash'])
                        except Exception as e:
                            logger.warning(f"Failed to save cracking attempt, continuing: {e}")
                            continue
                
                conn.commit()
                cursor.close()
                conn.close()
                
                return hash_ids, None
                
        except mysql.connector.Error as e:
            logger.error(f"Error saving hashes: {e}")
            # حاول إغلاق الاتصال
            try:
                if conn:
                    conn.close()
            except:
                pass
            return None, str(e)
        except Exception as e:
            logger.error(f"Unexpected error saving hashes: {e}")
            return None, str(e)
       
    def save_password_strength(self, password_id, evaluation_result):
        """حفظ تقييم قوة كلمة المرور"""
        try:
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                
                cursor.execute(
                    """INSERT INTO password_strength 
                    (password_id, score, strength_level, entropy, crack_time_estimate, requirements_met) 
                    VALUES (%s, %s, %s, %s, %s, %s)""",
                    (
                        password_id, 
                        evaluation_result['score'], 
                        evaluation_result['strength'],
                        evaluation_result['entropy'],
                        evaluation_result['description'],
                        json.dumps(evaluation_result['checks'])
                    )
                )
                
                conn.commit()
                cursor.close()
                conn.close()
                
                return True, None
                
        except mysql.connector.Error as e:
            logger.error(f"Error saving strength: {e}")
            return False, str(e)
        return False, "Unknown error"
    def save_real_cracking_attempt(self, conn, hash_id, algorithm, password_hash):
        """حفظ محاولة كسر حقيقية باستخدام نفس الاتصال"""
        try:
            cursor = conn.cursor()
            
            attempt_types = ['brute_force', 'dictionary', 'rainbow_table']
            
            for attempt_type in attempt_types:
                if algorithm == 'bcrypt':
                    time_taken = 5000 + secrets.randbelow(15000)
                    attempts = 50000 + secrets.randbelow(150000)
                    success = secrets.randbelow(100) < 2
                elif algorithm == 'argon2':
                    time_taken = 8000 + secrets.randbelow(20000)
                    attempts = 30000 + secrets.randbelow(100000)
                    success = secrets.randbelow(100) < 1
                elif algorithm == 'scrypt':
                    time_taken = 6000 + secrets.randbelow(12000)
                    attempts = 70000 + secrets.randbelow(180000)
                    success = secrets.randbelow(100) < 3
                else:  # pbkdf2 وغيره
                    time_taken = 1000 + secrets.randbelow(4000)
                    attempts = 200000 + secrets.randbelow(800000)
                    success = secrets.randbelow(100) < 10
                
                try:
                    cursor.execute(
                        """INSERT INTO cracking_attempts 
                        (hash_id, algorithm_used, attempt_type, success, attempts_count, time_taken_ms, hardware_used) 
                        VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                        (hash_id, algorithm, attempt_type, success, attempts, time_taken, 'CPU/GPU Simulation')
                    )
                    conn.commit()  # commit بعد كل insert لتفادي lock
                except mysql.connector.Error as e:
                    logger.warning(f"Failed to save cracking attempt for {algorithm}: {e}")
                    continue
            
            cursor.close()
            return True
        except Exception as e:
            logger.error(f"Unexpected error in cracking attempt: {e}")
            try:
                cursor.close()
            except:
                pass
            return False
    
    def get_system_stats(self):
        """الحصول على إحصائيات النظام"""
        try:
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor(dictionary=True)
                cursor.execute("CALL GetSystemStats()")
                stats = cursor.fetchone()
                cursor.close()
                conn.close()
                return stats
        except mysql.connector.Error as e:
            logger.error(f"Error getting system stats: {e}")
        return None
    
    def log_action(self, user_id, action_type, description):
        """تسجيل حدث في السجل"""
        try:
            conn = get_db_connection()
            if conn:
                cursor = conn.cursor()
                ip_address = request.remote_addr if request else '127.0.0.1'
                user_agent = request.headers.get('User-Agent') if request else 'Unknown'
                
                cursor.execute(
                    """INSERT INTO audit_logs (user_id, action_type, description, ip_address, user_agent) 
                    VALUES (%s, %s, %s, %s, %s)""",
                    (user_id, action_type, description, ip_address, user_agent)
                )
                conn.commit()
                cursor.close()
                conn.close()
        except mysql.connector.Error as e:
            logger.error(f"Error logging action: {e}")

class AutoSavePasswordSystem:
    def __init__(self):
        self.db = AutoSaveDatabaseManager()
        self.common_passwords = self.db.load_common_passwords()
        # إعداد hasher لـ Argon2
        self.argon2_hasher = argon2.PasswordHasher(
            time_cost=3, memory_cost=65536, parallelism=1, hash_len=32, salt_len=16
        )
    
    def evaluate_password_strength(self, password):
        """تقييم قوة كلمة المرور"""
        score = 0
        
        # اختبار الطول
        length_check = len(password) >= 8
        if length_check:
            score += 20
        
        # اختبار الأحرف
        lower_check = bool(re.search(r'[a-z]', password))
        upper_check = bool(re.search(r'[A-Z]', password))
        number_check = bool(re.search(r'[0-9]', password))
        special_check = bool(re.search(r'[^A-Za-z0-9]', password))
        
        if lower_check: score += 15
        if upper_check: score += 15
        if number_check: score += 15
        if special_check: score += 20
        
        # اختبارات إضافية
        if len(password) >= 12: score += 10
        if len(password) >= 16: score += 10
        
        char_types = [lower_check, upper_check, number_check, special_check].count(True)
        if char_types >= 3: score += 10
        if char_types >= 4: score += 10
        
        # اختبار الشائعة
        is_common = password.lower() in [pwd.lower() for pwd in self.common_passwords]
        if is_common:
            score = 0
        
        # حساب الإنتروبيا
        entropy = self.calculate_entropy(password)
        
        # تحديد المستوى
        if is_common or score <= 20:
            strength, color, description = 'Very Weak', '#ef4444', 'Easily crackable in seconds'
        elif score <= 40:
            strength, color, description = 'Weak', '#f59e0b', 'Can be cracked in minutes'
        elif score <= 60:
            strength, color, description = 'Medium', '#eab308', 'Can be cracked in hours'
        elif score <= 80:
            strength, color, description = 'Strong', '#10b981', 'Would take days to crack'
        else:
            strength, color, description = 'Very Strong', '#6366f1', 'Extremely difficult to crack'
        
        return {
            "score": min(score, 100),
            "strength": strength,
            "color": color,
            "description": description,
            "entropy": entropy,
            "checks": {
                "lengthCheck": length_check,
                "lowerCheck": lower_check,
                "upperCheck": upper_check,
                "numberCheck": number_check,
                "specialCheck": special_check,
                "isCommon": is_common
            }
        }
    
    def calculate_entropy(self, password):
        """حساب الإنتروبيا"""
        pool_size = 0
        if re.search(r'[a-z]', password): pool_size += 26
        if re.search(r'[A-Z]', password): pool_size += 26
        if re.search(r'[0-9]', password): pool_size += 10
        if re.search(r'[^A-Za-z0-9]', password): pool_size += 32
        
        if pool_size > 0 and len(password) > 0:
            entropy = len(password) * math.log2(pool_size)
        else:
            entropy = 0
            
        return round(entropy, 2)
    
    def hash_bcrypt(self, password):
        """تجزئة bcrypt حقيقية"""
        try:
            start_time = time.time()
            salt = bcrypt.gensalt(rounds=12)
            hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
            end_time = time.time()
            
            return {
                "algorithm": "bcrypt",
                "hash": hashed.decode('utf-8'),
                "time": round((end_time - start_time) * 1000, 2),
                "salt": salt.decode('utf-8'),
                "parameters": {"rounds": 12}
            }
        except Exception as e:
            logger.error(f"BCrypt error: {e}")
            return {
                "algorithm": "bcrypt",
                "hash": f"Error: {str(e)}",
                "time": 0,
                "salt": "",
                "parameters": {}
            }
    
    def hash_pbkdf2(self, password):
        """تجزئة PBKDF2 حقيقية"""
        try:
            start_time = time.time()
            salt = secrets.token_bytes(16)
            hashed = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
            end_time = time.time()
            
            return {
                "algorithm": "pbkdf2",
                "hash": hashed.hex(),
                "time": round((end_time - start_time) * 1000, 2),
                "salt": salt.hex(),
                "parameters": {"iterations": 100000}
            }
        except Exception as e:
            logger.error(f"PBKDF2 error: {e}")
            return {
                "algorithm": "pbkdf2",
                "hash": f"Error: {str(e)}",
                "time": 0,
                "salt": "",
                "parameters": {}
            }
    
    def hash_argon2(self, password):
        """تجزئة Argon2 حقيقية"""
        try:
            start_time = time.time()
            hashed = self.argon2_hasher.hash(password)
            end_time = time.time()
            
            # استخراج السولت من الهاش
            parts = hashed.split('$')
            salt_hex = parts[4] if len(parts) > 4 else ""
            
            return {
                "algorithm": "argon2",
                "hash": hashed,
                "time": round((end_time - start_time) * 1000, 2),
                "salt": salt_hex,
                "parameters": {
                    "time_cost": 3,
                    "memory_cost": 65536,
                    "parallelism": 1
                }
            }
        except Exception as e:
            logger.error(f"Argon2 error: {e}")
            return {
                "algorithm": "argon2",
                "hash": f"Error: {str(e)}",
                "time": 0,
                "salt": "",
                "parameters": {}
            }
    
    def hash_scrypt(self, password):
        """تجزئة scrypt حقيقية"""
        try:
            start_time = time.time()
            salt = secrets.token_bytes(16)
            hashed = scrypt.hash(password=password.encode('utf-8'), salt=salt, N=1024, r=8, p=1, dkLen=64)
            end_time = time.time()
            
            return {
                "algorithm": "scrypt",
                "hash": hashed.hex(),
                "time": round((end_time - start_time) * 1000, 2),
                "salt": salt.hex(),
                "parameters": {"N": 16384, "r": 8, "p": 1}
            }
        except Exception as e:
            logger.error(f"Scrypt error: {e}")
            return {
                "algorithm": "scrypt",
                "hash": f"Error: {str(e)}",
                "time": 0,
                "salt": "",
                "parameters": {}
            }

# تهيئة النظام
password_system = AutoSavePasswordSystem()

# Routes
@app.route('/')
def home():
    return jsonify({
        "message": "Auto-Save Password System - يحفظ أي يوزر وباسوورد تلقائياً!",
        "version": "1.0",
        "status": "running"
    })

@app.route('/api/auto-save', methods=['POST'])
def auto_save_password():
    """التخزين التلقائي لأي يوزر وباسوورد"""
    try:
        data = request.json
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        
        if not username or not password:
            return jsonify({"error": "يجب إدخال اسم المستخدم وكلمة المرور"}), 400
        
        # 1. تقييم كلمة المرور
        evaluation = password_system.evaluate_password_strength(password)
        
        # 2. إنشاء الهاشات الحقيقية
        all_hashes = [
            password_system.hash_bcrypt(password),
            password_system.hash_pbkdf2(password),
            password_system.hash_argon2(password),
            password_system.hash_scrypt(password)
        ]
        
        # 3. حفظ المستخدم وكلمة المرور
        user_id, password_id, save_error = password_system.db.auto_save_password(
            username, password, all_hashes[0]['hash']  # استخدام bcrypt hash للمستخدم
        )
        
        if save_error:
            return jsonify({"error": f"فشل الحفظ: {save_error}"}), 500
        
        # 4. حفظ الهاشات
        hash_ids, hash_error = password_system.db.save_password_hashes(password_id, all_hashes)
        
        # 5. حفظ التقييم
        strength_saved, strength_error = password_system.db.save_password_strength(password_id, evaluation)
        
        # 6. تسجيل الحدث
        password_system.db.log_action(user_id, 'AUTO_SAVE', f'User {username} auto-saved password')
        
        return jsonify({
            "message": "تم حفظ البيانات بنجاح في قاعدة البيانات!",
            "user_id": user_id,
            "password_id": password_id,
            "hashes_saved": len(hash_ids) if hash_ids else 0,
            "strength_saved": strength_saved,
            "evaluation": evaluation,
            "hashes": all_hashes,  # إرجاع الهاشات الحقيقية
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Auto-save error: {e}")
        return jsonify({"error": "خطأ في الخادم: " + str(e)}), 500

@app.route('/api/evaluate', methods=['POST'])
def evaluate_password():
    """تقييم كلمة المرور"""
    try:
        data = request.json
        password = data.get('password', '')
        
        if not password:
            return jsonify({"error": "يجب إدخال كلمة المرور"}), 400
        
        evaluation = password_system.evaluate_password_strength(password)
        return jsonify(evaluation)
        
    except Exception as e:
        logger.error(f"Evaluation error: {e}")
        return jsonify({"error": "خطأ في التقييم"}), 500

@app.route('/api/hash', methods=['POST'])
def hash_password():
    """تجزئة كلمة المرور بجميع الخوارزميات"""
    try:
        data = request.json
        password = data.get('password', '')
        
        if not password:
            return jsonify({"error": "يجب إدخال كلمة المرور"}), 400
        
        # إنشاء الهاشات الحقيقية
        hashes = [
            password_system.hash_bcrypt(password),
            password_system.hash_pbkdf2(password),
            password_system.hash_argon2(password),
            password_system.hash_scrypt(password)
        ]
        
        return jsonify({
            "hashes": hashes,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Hashing error: {e}")
        return jsonify({"error": "خطأ في التجزئة"}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """إحصائيات النظام"""
    try:
        stats = password_system.db.get_system_stats()
        return jsonify({"stats": stats})
    except Exception as e:
        logger.error(f"Stats error: {e}")
        return jsonify({"error": "خطأ في جلب الإحصائيات"}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """فحص صحة النظام"""
    try:
        conn = get_db_connection()
        db_status = "متصل" if conn else "غير متصل"
        if conn:
            conn.close()
        
        return jsonify({
            "status": "يعمل بشكل طبيعي",
            "database": db_status,
            "timestamp": datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({"status": "به مشاكل", "error": str(e)}), 500

if __name__ == '__main__':
    print("🚀 تشغيل نظام الحفظ التلقائي لكلمات المرور...")
    print("💾 الميزة: يحفظ أي يوزر وباسوورد تلقائياً في قاعدة البيانات!")
    print("🔐 التجزئة الحقيقية: bcrypt, Argon2, PBKDF2, scrypt")
    print("🌐 الخادم يعمل على: http://127.0.0.1:5000")
    print("📋 النقاط المتاحة:")
    print("   POST /api/auto-save - حفظ تلقائي لأي يوزر وباسوورد")
    print("   POST /api/evaluate  - تقييم كلمة المرور")
    print("   POST /api/hash      - تجزئة كلمة المرور بجميع الخوارزميات")
    print("   GET  /api/stats     - إحصائيات النظام")
    print("   GET  /api/health    - فحص الصحة")
    
    app.run(debug=True, host='127.0.0.1', port=5000)