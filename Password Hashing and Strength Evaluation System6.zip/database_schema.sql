-- حذف وإنشاء قاعدة البيانات
DROP DATABASE IF EXISTS password_security_system;
CREATE DATABASE password_security_system;
USE password_security_system;

-- جدول سياسات كلمات المرور
CREATE TABLE password_policy (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_name VARCHAR(100) NOT NULL UNIQUE,
    min_length INT DEFAULT 8,
    max_length INT DEFAULT 128,
    require_number BOOLEAN DEFAULT TRUE,
    require_special_char BOOLEAN DEFAULT TRUE,
    require_lowercase BOOLEAN DEFAULT TRUE,
    require_uppercase BOOLEAN DEFAULT TRUE,
    block_common_passwords BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول المستخدمين (سيخزن أي يوزر يدخله المستخدم)
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_temporary BOOLEAN DEFAULT TRUE, -- مستخدم مؤقت
    UNIQUE KEY unique_username (username)
);

-- جدول خوارزميات التجزئة
CREATE TABLE hashing_algorithms (
    algorithm_id INT AUTO_INCREMENT PRIMARY KEY,
    algorithm_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول كلمات المرور الرئيسي
CREATE TABLE passwords (
    password_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plain_password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- جدول الهاشات
CREATE TABLE password_hashes (
    hash_id INT AUTO_INCREMENT PRIMARY KEY,
    password_id INT NOT NULL,
    algorithm_id INT NOT NULL,
    password_hash VARCHAR(512) NOT NULL,
    salt VARCHAR(255),
    parameters JSON,
    hashing_time_ms DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (password_id) REFERENCES passwords(password_id) ON DELETE CASCADE,
    FOREIGN KEY (algorithm_id) REFERENCES hashing_algorithms(algorithm_id)
);

-- جدول قوة كلمات المرور
CREATE TABLE password_strength (
    strength_id INT AUTO_INCREMENT PRIMARY KEY,
    password_id INT NOT NULL,
    score INT NOT NULL CHECK (score BETWEEN 0 AND 100),
    strength_level ENUM('Very Weak', 'Weak', 'Medium', 'Strong', 'Very Strong') NOT NULL,
    entropy DECIMAL(8,2),
    crack_time_estimate VARCHAR(50),
    requirements_met JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (password_id) REFERENCES passwords(password_id) ON DELETE CASCADE
);

-- جدول محاولات الكسر
CREATE TABLE cracking_attempts (
    attempt_id INT AUTO_INCREMENT PRIMARY KEY,
    hash_id INT NOT NULL,
    algorithm_used VARCHAR(50) NOT NULL,
    attempt_type ENUM('brute_force', 'dictionary', 'rainbow_table', 'hybrid') NOT NULL,
    success BOOLEAN DEFAULT FALSE,
    attempts_count BIGINT,
    time_taken_ms DECIMAL(12,2),
    hardware_used VARCHAR(100),
    cracked_password VARCHAR(255),
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (hash_id) REFERENCES password_hashes(hash_id) ON DELETE CASCADE
);

-- جدول كلمات المرور الشائعة
CREATE TABLE common_passwords (
    common_password_id INT AUTO_INCREMENT PRIMARY KEY,
    password VARCHAR(255) NOT NULL UNIQUE,
    frequency_count INT DEFAULT 0,
    risk_level ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'High',
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول سجل الأحداث
CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action_type VARCHAR(50) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- إدراج البيانات الأولية
INSERT INTO password_policy (policy_name) VALUES ('Auto-Save Policy');

INSERT INTO hashing_algorithms (algorithm_name, description) VALUES 
('bcrypt', 'Adaptive hashing function based on Blowfish cipher'),
('argon2', 'Memory-hard function, winner of Password Hashing Competition'),
('pbkdf2', 'Password-Based Key Derivation Function 2'),
('scrypt', 'Memory-hard key derivation function');

INSERT INTO common_passwords (password, risk_level) VALUES 
('123456', 'Critical'), ('password', 'Critical'), ('12345678', 'Critical'),
('qwerty', 'Critical'), ('abc123', 'High'), ('123456789', 'Critical');

-- إنشاء إجراءات مخزنة
DELIMITER //

CREATE PROCEDURE AutoSavePassword(
    IN username_param VARCHAR(50),
    IN plain_password_param VARCHAR(255),
    IN password_hash_param VARCHAR(255)
)
BEGIN
    DECLARE user_id_val INT;
    DECLARE password_id_val INT;
    DECLARE existing_user_id INT;
    
    -- البحث عن المستخدم أو إنشاؤه
    SELECT user_id INTO existing_user_id FROM users WHERE username = username_param;
    
    IF existing_user_id IS NULL THEN
        -- إنشاء مستخدم جديد
        INSERT INTO users (username, password_hash, is_temporary) 
        VALUES (username_param, password_hash_param, TRUE);
        SET user_id_val = LAST_INSERT_ID();
    ELSE
        SET user_id_val = existing_user_id;
    END IF;
    
    -- حفظ كلمة المرور
    INSERT INTO passwords (user_id, plain_password) VALUES (user_id_val, plain_password_param);
    SET password_id_val = LAST_INSERT_ID();
    
    -- إرجاع المعرفات
    SELECT user_id_val as user_id, password_id_val as password_id;
END //

CREATE PROCEDURE GetSystemStats()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM passwords) as total_passwords,
        (SELECT COUNT(*) FROM password_hashes) as total_hashes,
        (SELECT COUNT(*) FROM cracking_attempts) as total_cracking_attempts,
        (SELECT AVG(score) FROM password_strength) as avg_password_score;
END //

DELIMITER ;

-- إنشاء الفهارس
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_passwords_user_id ON passwords(user_id);
CREATE INDEX idx_password_hashes_password_id ON password_hashes(password_id);

SELECT 'Auto-save database schema created successfully!' as message;